#!/bin/bash

bin_name=delib_eth.so
preprocessor_defines="-D USE_ETH"

list_of_files="
../../delib-sources/delib/library/vc/deditec_timer.c
../../delib-sources/delib/library/vc/deditec_convert_functions.c
../../delib-sources/delib/library/vc/deditec_tcp_io.c
../../delib-sources/delib/library/vc/deditec_buff_utils.c
../../delib-sources/delib/library/vc/deditec_string_utils.c
../../delib-sources/delib/library/embedded/deditec_debug_comfort.c
../../delib-sources/delib/delib_debug.c

../../delib-sources/delib/delib_hdlmgr.c
../../delib-sources/delib/delib_packet_statistic.c
../../delib-sources/delib/delib_Dapi_di_do_ad_da_befehle.c
../../delib-sources/delib/delib_set_get_error.c
../../delib-sources/delib/delib_Dapi_register_commands.c
../../delib-sources/delib/delib_open_close.c
../../delib-sources/delib/delib_io_tcp.c
-g"

echo now compiling $bin_name
gcc $preprocessor_defines -shared -fpic -o $bin_name $list_of_files -w

if [ $? != "0" ]
   then echo
        echo "error(s) found while compiling"
        exit 100
   else echo
        echo "compiling successfull"
fi
